# REST API client: auth, rate limiting, caching, retry

## Overview
A production-quality api wrapper.

## Installation
```bash
# stdlib only - no dependencies needed
```

## Usage
```bash
python main.py --help
```

## License
MIT
