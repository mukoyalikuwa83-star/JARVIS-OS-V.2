#!/usr/bin/env python3
"""REST API Client - Production Quality
GET/POST/PUT/DELETE with auth, retry, caching.
Usage: python client.py https://api.example.com --path /users
"""
import json, time, hashlib, logging, urllib.request, urllib.parse, ssl
from pathlib import Path
from functools import wraps

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger(__name__)

CTX = ssl.create_default_context()
CTX.check_hostname = False
CTX.verify_mode = ssl.CERT_NONE


def retry(max_retries=3, delay=1.0):
    def dec(f):
        @wraps(f)
        def wrapper(*a, **kw):
            for i in range(max_retries):
                try: return f(*a, **kw)
                except Exception as e:
                    if i == max_retries-1: raise
                    log.warning("Retry %d/%d: %s", i+1, max_retries, e)
                    time.sleep(delay*(i+1))
        return wrapper
    return dec


class Client:
    def __init__(self, base, headers=None, cache_ttl=300):
        self.base = base.rstrip("/")
        self.headers = headers or {}
        self.cache_ttl = cache_ttl
        self.cache = {}
        self.count = 0

    def _url(self, path, params=None):
        u = f"{self.base}/{path.lstrip('/')}"
        if params: u += "?" + urllib.parse.urlencode(params)
        return u

    def _ck(self, method, url, data=None):
        return hashlib.md5(f"{method}:{url}:{json.dumps(data, sort_keys=True) if data else ''}".encode()).hexdigest()

    def _req(self, method, path, data=None, params=None, cache=True):
        url = self._url(path, params)
        ck = self._ck(method, url, data)
        if cache and method == "GET" and ck in self.cache:
            ct, cv = self.cache[ck]
            if time.time() - ct < self.cache_ttl: return cv
        body = json.dumps(data).encode() if data else None
        h = {**self.headers, "User-Agent": "APIClient/1.0"}
        if body: h["Content-Type"] = "application/json"
        req = urllib.request.Request(url, data=body, headers=h, method=method)
        t0 = time.time()
        with urllib.request.urlopen(req, context=CTX, timeout=30) as resp:
            result = json.loads(resp.read().decode())
            log.info("%s %s -> %d (%.2fs)", method, url, resp.status, time.time()-t0)
            self.count += 1
            if cache and method == "GET": self.cache[ck] = (time.time(), result)
            return result

    @retry()
    def get(self, path, params=None): return self._req("GET", path, params=params)

    @retry(max_retries=2)
    def post(self, path, data=None): return self._req("POST", path, data=data, cache=False)

    @retry(max_retries=2)
    def put(self, path, data=None): return self._req("PUT", path, data=data, cache=False)

    @retry(max_retries=2)
    def delete(self, path): return self._req("DELETE", path, cache=False)

    def stats(self): return {"requests": self.count, "base": self.base}


if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser(description="REST API Client")
    p.add_argument("base_url")
    p.add_argument("--path", default="/")
    p.add_argument("--method", default="GET", choices=["GET","POST","PUT","DELETE"])
    p.add_argument("--data")
    a = p.parse_args()
    c = Client(a.base_url)
    d = json.loads(a.data) if a.data else None
    r = c.get(a.path) if a.method == "GET" else getattr(c, a.method.lower())(a.path, d)
    print(json.dumps(r, indent=2, default=str))
    print(f"Stats: {c.stats()}")
