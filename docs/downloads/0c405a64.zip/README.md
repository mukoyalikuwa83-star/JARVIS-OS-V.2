# User authentication API with JWT

## Overview
A production-quality flask api.

## Installation
```bash
pip install -r requirements.txt
```

## Usage
```bash
python main.py --help
```

## License
MIT
