#!/usr/bin/env python3
"""Discord Bot - Full Featured
Moderation, welcome, logging, userinfo, serverinfo.
Requires: pip install discord.py
"""
import discord
from discord.ext import commands
import json
from pathlib import Path

CFG = Path("config.json")
DEF = {"prefix": "!", "welcome": None, "log": None}


def load_cfg():
    if CFG.exists(): return json.loads(CFG.read_text("utf-8"))
    CFG.write_text(json.dumps(DEF, indent=2), "utf-8")
    return DEF


c = load_cfg()
bot = commands.Bot(command_prefix=c["prefix"], intents=discord.Intents.all())


@bot.event
async def on_ready():
    print(f"Ready: {bot.user} | {len(bot.guilds)} servers")
    await bot.change_presence(activity=discord.Activity(
        type=discord.ActivityType.watching, name="the server | !help"))


@bot.command()
@commands.has_permissions(administrator=True)
async def setup(ctx, ch: discord.TextChannel = None):
    c["welcome"] = ch.id if ch else ctx.channel.id
    CFG.write_text(json.dumps(c, indent=2))
    await ctx.send("Welcome channel set!")


@bot.command()
@commands.has_permissions(manage_messages=True)
async def purge(ctx, n: int = 10):
    d2 = await ctx.channel.purge(limit=n+1)
    await ctx.send(f"Deleted {len(d2)-1}", delete_after=5)


@bot.command()
async def userinfo(ctx, m: discord.Member = None):
    m = m or ctx.author
    e = discord.Embed(title=str(m), color=m.color)
    e.add_field(name="ID", value=m.id)
    e.add_field(name="Roles", value=len(m.roles))
    e.set_thumbnail(url=m.display_avatar.url)
    await ctx.send(embed=e)


@bot.command()
async def serverinfo(ctx):
    g = ctx.guild
    e = discord.Embed(title=g.name, color=discord.Color.blue())
    e.add_field(name="Members", value=g.member_count)
    e.add_field(name="Channels", value=len(g.channels))
    if g.icon: e.set_thumbnail(url=g.icon.url)
    await ctx.send(embed=e)


@bot.command()
@commands.has_permissions(manage_roles=True)
async def mute(ctx, m: discord.Member, reason: str = "No reason"):
    role = discord.utils.get(ctx.guild.roles, name="Muted")
    if not role:
        role = await ctx.guild.create_role(name="Muted")
        for ch in ctx.guild.channels:
            await ch.set_permissions(role, send_messages=False)
    await m.add_roles(role, reason=reason)
    await ctx.send(f"Muted {m.mention}: {reason}")


@bot.command()
@commands.has_permissions(manage_roles=True)
async def unmute(ctx, m: discord.Member):
    role = discord.utils.get(ctx.guild.roles, name="Muted")
    if role:
        await m.remove_roles(role)
        await ctx.send(f"Unmuted {m.mention}")


@bot.command()
@commands.has_permissions(ban_members=True)
async def ban(ctx, m: discord.Member, reason: str = "No reason"):
    await m.ban(reason=reason)
    await ctx.send(f"Banned {m.mention}: {reason}")


@bot.command()
@commands.has_permissions(kick_members=True)
async def kick(ctx, m: discord.Member, reason: str = "No reason"):
    await m.kick(reason=reason)
    await ctx.send(f"Kicked {m.mention}: {reason}")


@bot.event
async def on_member_join(m):
    ch = bot.get_channel(c.get("welcome", 0))
    if ch:
        e = discord.Embed(title="Welcome!",
            description=f"Welcome {m.mention} to **{m.guild.name}**!",
            color=discord.Color.green())
        await ch.send(embed=e)


if __name__ == "__main__":
    import os
    t = os.environ.get("DISCORD_TOKEN")
    if t: bot.run(t)
    else: print("Set DISCORD_TOKEN env var")
