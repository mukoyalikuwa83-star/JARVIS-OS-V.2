# Discord Bot with Moderation, Economy, Music, AI Chat

## Overview
A production-quality discord bot.

## Installation
```bash
pip install discord.py
```

## Usage
```bash
python bot.py
```

## License
MIT
