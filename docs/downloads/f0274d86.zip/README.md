# Real estate scraper with listings

## Overview
A production-quality web scraper.

## Installation
```bash
# stdlib only - no dependencies needed
```

## Usage
```bash
python scraper.py --urls https://example.com
```

## License
MIT
