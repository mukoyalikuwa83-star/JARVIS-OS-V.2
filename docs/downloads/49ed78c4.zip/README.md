# SaaS template with billing and auth

## Overview
A production-quality telegram bot.

## Installation
```bash
pip install python-telegram-bot
```

## Usage
```bash
python bot.py
```

## License
MIT
