"""Multi-API Integration Client
Handles authentication, rate limiting, retries, caching for multiple APIs.
"""
import json, time, hashlib, logging, functools, urllib.request, urllib.error, ssl
from pathlib import Path
from datetime import datetime, timedelta

log = logging.getLogger(__name__)

class APIClient:
    def __init__(self, name, base_url, api_key=None, rate_limit=60):
        self.name = name
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.rate_limit = rate_limit
        self._last_request = 0
        self._cache = {}
        self._cache_dir = Path("cache") / name
        self._cache_dir.mkdir(parents=True, exist_ok=True)
        self._ssl_ctx = ssl.create_default_context()
        self._ssl_ctx.check_hostname = False
        self._ssl_ctx.verify_mode = ssl.CERT_NONE

    def _throttle(self):
        elapsed = time.time() - self._last_request
        min_interval = 60.0 / self.rate_limit
        if elapsed < min_interval:
            time.sleep(min_interval - elapsed)
        self._last_request = time.time()

    def _cache_key(self, url, params):
        raw = json.dumps({"url": url, "params": params}, sort_keys=True)
        return hashlib.md5(raw.encode()).hexdigest()

    def get(self, path, params=None, use_cache=True):
        url = f"{self.base_url}/{path.lstrip('/')}"
        self._throttle()
        if use_cache:
            key = self._cache_key(url, params)
            cached = self._cache.get(key)
            if cached and cached["expires"] > datetime.now():
                log.info("[%s] Cache hit: %s", self.name, path)
                return cached["data"]
        headers = {"User-Agent": f"APIClient/{self.name}", "Accept": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        if params:
            query = "&".join(f"{k}={v}" for k, v in params.items() if v is not None)
            url = f"{url}?{query}"
        req = urllib.request.Request(url, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=15, context=self._ssl_ctx) as resp:
                data = json.loads(resp.read().decode())
            if use_cache:
                self._cache[self._cache_key(url, params)] = {
                    "data": data, "expires": datetime.now() + timedelta(minutes=5)}
            return data
        except urllib.error.HTTPError as e:
            log.error("[%s] HTTP %d: %s", self.name, e.code, e.reason)
            return {"error": e.code, "message": str(e)}
        except Exception as e:
            log.error("[%s] Request failed: %s", self.name, e)
            return {"error": "request_failed", "message": str(e)}

    def post(self, path, body=None):
        url = f"{self.base_url}/{path.lstrip('/')}"
        self._throttle()
        headers = {"User-Agent": f"APIClient/{self.name}", "Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        data = json.dumps(body or {}).encode()
        req = urllib.request.Request(url, data=data, headers=headers, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=15, context=self._ssl_ctx) as resp:
                return json.loads(resp.read().decode())
        except Exception as e:
            log.error("[%s] POST failed: %s", self.name, e)
            return {"error": "post_failed", "message": str(e)}

    def bulk_get(self, paths, max_concurrent=5):
        results = {}
        for i, path in enumerate(paths):
            if i >= max_concurrent:
                time.sleep(60.0 / self.rate_limit)
            results[path] = self.get(path)
        return results


class APIHub:
    def __init__(self, config_file="api_config.json"):
        self.config_file = Path(config_file)
        self.clients = {}
        self._load_config()

    def _load_config(self):
        if self.config_file.exists():
            cfg = json.loads(self.config_file.read_text())
            for name, c in cfg.get("apis", {}).items():
                self.clients[name] = APIClient(name, c["url"], c.get("key"), c.get("rate_limit", 60))

    def register(self, name, url, api_key=None, rate_limit=60):
        self.clients[name] = APIClient(name, url, api_key, rate_limit)
        self._save_config()

    def _save_config(self):
        cfg = {"apis": {}}
        for name, c in self.clients.items():
            cfg["apis"][name] = {"url": c.base_url, "key": c.api_key, "rate_limit": c.rate_limit}
        self.config_file.write_text(json.dumps(cfg, indent=2))

    def get(self, api_name, path, params=None):
        client = self.clients.get(api_name)
        if not client:
            return {"error": f"Unknown API: {api_name}"}
        return client.get(path, params)

    def status(self):
        return {name: {"url": c.base_url, "rate_limit": c.rate_limit} for name, c in self.clients.items()}


if __name__ == "__main__":
    hub = APIHub()
    hub.register("jsonplaceholder", "https://jsonplaceholder.typicode.com")
    print(json.dumps(hub.get("jsonplaceholder", "/posts/1"), indent=2))
