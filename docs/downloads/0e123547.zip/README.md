# E-commerce API with auth, payments, inventory

## Overview
A production-quality discord bot.

## Installation
```bash
pip install discord.py
```

## Usage
```bash
python bot.py
```

## License
MIT
