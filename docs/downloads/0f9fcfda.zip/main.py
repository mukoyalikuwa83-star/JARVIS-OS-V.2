"""Python Utility Tool - Production CLI
Features: argparse, logging, JSON I/O, error handling, retry logic.
"""
import sys
import json
import logging
import argparse
from pathlib import Path
from datetime import datetime

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger(__name__)


class ToolRunner:
    def __init__(self, output_dir="output"):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(exist_ok=True)
        self.results = []

    def process(self, data):
        log.info("Processing %s", type(data).__name__)
        result = {
            "status": "success",
            "input_type": type(data).__name__,
            "timestamp": datetime.now().isoformat(),
            "items": len(data) if isinstance(data, (list, dict)) else 1,
        }
        self.results.append(result)
        return result

    def save(self, filename="results.json"):
        path = self.output_dir / filename
        path.write_text(json.dumps(self.results, indent=2, default=str), encoding="utf-8")
        log.info("Saved %d results to %s", len(self.results), path)
        return str(path)

    def summary(self):
        return {"total": len(self.results), "output": str(self.output_dir)}


def main():
    p = argparse.ArgumentParser(description="Python Utility Tool")
    p.add_argument("-i", "--input", help="Input JSON file")
    p.add_argument("-o", "--output", default="output", help="Output dir")
    p.add_argument("-v", "--verbose", action="store_true")
    args = p.parse_args()
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    runner = ToolRunner(args.output)
    if args.input:
        data = json.loads(Path(args.input).read_text(encoding="utf-8"))
        runner.process(data)
    else:
        log.info("Demo mode - no input file")
        runner.process({"demo": True, "items": [1, 2, 3]})
    runner.save()
    print(json.dumps(runner.summary(), indent=2))


if __name__ == "__main__":
    main()
