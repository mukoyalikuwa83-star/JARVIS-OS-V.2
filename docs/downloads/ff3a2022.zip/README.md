# Task manager API with projects

## Overview
A production-quality flask api.

## Installation
```bash
pip install -r requirements.txt
```

## Usage
```bash
python main.py --help
```

## License
MIT
