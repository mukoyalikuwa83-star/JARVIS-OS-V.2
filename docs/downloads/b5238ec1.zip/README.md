# Auto-built cli_tool

## Overview
A production-quality cli tool.

## Installation
```bash
pip install -r requirements.txt
```

## Usage
```bash
python main.py --help
```

## License
MIT
