"""Web Dashboard - Flask app with HTML frontend, charts, data export."""
import os, json, secrets, csv, io, time
from datetime import datetime, timedelta
from flask import Flask, render_template_string, request, jsonify, send_file

app = Flask(__name__)
app.config["SECRET_KEY"] = secrets.token_hex(16)

DASHBOARD_HTML = """<!DOCTYPE html>
<html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{{ title }}</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:system-ui,sans-serif;background:#0f172a;color:#e2e8f0;min-height:100vh}
.sidebar{width:240px;background:#1e293b;height:100vh;position:fixed;padding:20px 0}
.sidebar h2{padding:0 20px 20px;font-size:1.2em;color:#38bdf8}
.sidebar a{display:block;padding:10px 20px;color:#94a3b8;text-decoration:none;font-size:0.9em}
.sidebar a:hover,.sidebar a.active{background:#334155;color:#fff}
.main{margin-left:240px;padding:30px}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:20px;margin-top:20px}
.card{background:#1e293b;border-radius:12px;padding:20px;border:1px solid #334155}
.card h3{color:#38bdf8;margin-bottom:12px;font-size:1em}
.stat{font-size:2em;font-weight:700;color:#fff}
.stat-label{color:#64748b;font-size:0.85em;margin-top:4px}
table{width:100%;border-collapse:collapse;margin-top:16px}
th,td{text-align:left;padding:10px 12px;border-bottom:1px solid #334155;font-size:0.9em}
th{color:#64748b;font-weight:500}
.badge{display:inline-block;padding:2px 10px;border-radius:12px;font-size:0.75em;font-weight:600}
.badge-green{background:#064e3b;color:#34d399}
.badge-blue{background:#1e3a5f;color:#38bdf8}
.badge-yellow{background:#713f12;color:#fbbf24}
.btn{background:#38bdf8;color:#0f172a;padding:8px 16px;border:none;border-radius:6px;
     cursor:pointer;font-weight:600;font-size:0.85em}
.btn:hover{opacity:0.9}
.chart{height:200px;background:#0f172a;border-radius:8px;margin-top:12px;
       display:flex;align-items:flex-end;padding:10px;gap:4px}
.bar{background:linear-gradient(to top,#38bdf8,#7b2ff7);border-radius:4px 4px 0 0;
     flex:1;min-height:10px;transition:height 0.3s}
</style></head><body>
<div class="sidebar">
<h2>{{ title }}</h2>
<a href="/" class="active">Dashboard</a>
<a href="/data">Data</a>
<a href="/api/stats">API Stats</a>
<a href="/export">Export CSV</a>
</div>
<div class="main">
<h1>Dashboard</h1>
<p style="color:#64748b;margin-top:4px">Last updated: {{ now }}</p>
<div class="grid">
<div class="card"><h3>Total Records</h3><div class="stat">{{ stats.total }}</div><div class="stat-label">across all categories</div></div>
<div class="card"><h3>Active Today</h3><div class="stat">{{ stats.active }}</div><div class="stat-label">items modified today</div></div>
<div class="card"><h3>Growth</h3><div class="stat">{{ stats.growth }}%</div><div class="stat-label">vs last period</div></div>
</div>
<div class="card" style="margin-top:20px">
<h3>Weekly Activity</h3>
<div class="chart">{% for v in chart_data %}<div class="bar" style="height:{{ v }}%"></div>{% endfor %}</div>
</div>
<div class="card" style="margin-top:20px">
<h3>Recent Items</h3>
<table><tr><th>Name</th><th>Category</th><th>Status</th><th>Updated</th></tr>
{% for item in items[:10] %}<tr>
<td>{{ item.name }}</td><td>{{ item.category }}</td>
<td><span class="badge badge-{{ item.badge }}">{{ item.status }}</span></td>
<td>{{ item.updated }}</td></tr>{% endfor %}</table>
</div>
</div></body></html>"""

_data = [{"name": f"Item {i}", "category": cat, "status": st,
          "updated": (datetime.now() - timedelta(hours=i)).strftime("%Y-%m-%d %H:%M"),
          "badge": {"Active": "green", "Pending": "yellow", "Draft": "blue"}.get(st, "blue")}
         for i, cat, st in enumerate(
             ["Sales", "Marketing", "Dev", "Support", "Finance",
              "Sales", "Marketing", "Dev", "Support", "Finance",
              "Sales", "Marketing", "Dev", "Support", "Finance"],
             1) for st in (["Active", "Pending", "Draft"][:1] if i % 3 == 0 else ["Active"])]

@app.route("/")
def dashboard():
    chart_data = [30 + (i * 7) % 60 for i in range(7)]
    return render_template_string(DASHBOARD_HTML, title="Dashboard",
                                  now=datetime.now().strftime("%Y-%m-%d %H:%M"),
                                  stats={"total": len(_data), "active": len([d for d in _data if d["status"] == "Active"]),
                                         "growth": 12},
                                  chart_data=chart_data, items=_data)

@app.route("/data")
def data_page():
    return jsonify({"items": _data, "count": len(_data)})

@app.route("/api/stats")
def api_stats():
    return jsonify({"total": len(_data), "active": len([d for d in _data if d["status"] == "Active"]),
                    "categories": list(set(d["category"] for d in _data))})

@app.route("/export")
def export_csv():
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=["name", "category", "status", "updated"])
    writer.writeheader()
    writer.writerows(_data)
    output.seek(0)
    return send_file(io.BytesIO(output.getvalue().encode()), mimetype="text/csv",
                     as_attachment=True, download_name="export.csv")

@app.route("/api/add", methods=["POST"])
def add_item():
    data = request.get_json() or {}
    item = {"name": data.get("name", "New Item"), "category": data.get("category", "General"),
            "status": "Active", "updated": datetime.now().strftime("%Y-%m-%d %H:%M"), "badge": "green"}
    _data.insert(0, item)
    return jsonify(item), 201

if __name__ == "__main__":
    print("Dashboard at http://localhost:5000")
    app.run(host="0.0.0.0", port=5000, debug=True)
