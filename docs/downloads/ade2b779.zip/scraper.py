#!/usr/bin/env python3
"""Web Scraper - Production Quality
Multi-URL scraper with retry, rate limiting, CSV+JSON export.
"""
import json, csv, time, re, logging, argparse, urllib.request, ssl
from pathlib import Path
from datetime import datetime

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger(__name__)

CTX = ssl.create_default_context()
CTX.check_hostname = False
CTX.verify_mode = ssl.CERT_NONE
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124.0.0.0"


class Scraper:
    def __init__(self, delay=1.0, retries=3):
        self.delay, self.retries, self.results = delay, retries, []

    def fetch(self, url):
        for i in range(self.retries):
            try:
                req = urllib.request.Request(url, headers={"User-Agent": UA})
                with urllib.request.urlopen(req, context=CTX, timeout=15) as r:
                    return r.read().decode("utf-8", errors="replace")
            except Exception as e:
                log.warning("Retry %d: %s", i+1, e)
                time.sleep(self.delay * (i+1))
        return None

    def extract_links(self, html):
        return re.findall(r'href="(https?://[^"]+)"', html)

    def extract_text(self, html):
        t = re.sub(r"<script[^>]*>.*?</script>", "", html, flags=re.DOTALL)
        t = re.sub(r"<style[^>]*>.*?</style>", "", t, flags=re.DOTALL)
        t = re.sub(r"<[^>]+>", " ", t)
        return " ".join(t.split())[:5000]

    def scrape(self, urls):
        for url in urls:
            html = self.fetch(url)
            if html:
                self.results.append({"url": url, "ok": True, "len": len(html),
                    "links": len(self.extract_links(html)), "ts": str(datetime.now())})
            time.sleep(self.delay)
        return self.results

    def save_json(self, p="scraped.json"):
        Path(p).write_text(json.dumps(self.results, indent=2), encoding="utf-8")

    def save_csv(self, p="scraped.csv"):
        if not self.results: return
        with open(p, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=self.results[0].keys())
            w.writeheader(); w.writerows(self.results)


def main():
    pa = argparse.ArgumentParser()
    pa.add_argument("--urls", nargs="+")
    pa.add_argument("--file")
    pa.add_argument("--delay", type=float, default=1.0)
    pa.add_argument("--output", default="scraped")
    a = pa.parse_args()
    urls = list(a.urls) if a.urls else []
    if a.file: urls.extend(Path(a.file).read_text().strip().splitlines())
    if not urls: urls = ["https://httpbin.org/get"]
    s = Scraper(delay=a.delay)
    s.scrape(urls)
    s.save_json(f"{a.output}.json")
    s.save_csv(f"{a.output}.csv")
    print(f"Scraped {len(s.results)} URLs")


if __name__ == "__main__": main()
