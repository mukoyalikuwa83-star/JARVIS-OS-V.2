# Auto-backup: schedule, compress

## Overview
A production-quality automation script.

## Installation
```bash
pip install -r requirements.txt
```

## Usage
```bash
python main.py --help
```

## License
MIT
