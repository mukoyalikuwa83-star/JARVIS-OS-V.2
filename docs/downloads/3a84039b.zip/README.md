# Production ETL with CSV/JSON/JSONL, Transforms, Monitoring

## Overview
A production-quality etl pipeline.

## Installation
```bash
pip install -r requirements.txt
```

## Usage
```bash
python main.py --help
```

## License
MIT
