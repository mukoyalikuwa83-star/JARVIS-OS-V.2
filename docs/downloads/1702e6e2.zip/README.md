# Reporting pipeline: daily digest

## Overview
A production-quality data pipeline.

## Installation
```bash
pip install -r requirements.txt
```

## Usage
```bash
python main.py --help
```

## License
MIT
