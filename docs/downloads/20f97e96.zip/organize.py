#!/usr/bin/env python3
"""File Organizer
Organizes files by type, detects duplicates, supports dry run.
Usage: python organize.py C:\Users\Downloads
"""
import os, shutil, json, hashlib, logging, argparse
from pathlib import Path
from datetime import datetime
from collections import defaultdict

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger(__name__)

EXTS = {
    "Images": [".jpg",".jpeg",".png",".gif",".bmp",".webp",".svg"],
    "Documents": [".pdf",".doc",".docx",".txt",".rtf",".md"],
    "Spreadsheets": [".xls",".xlsx",".csv"],
    "Videos": [".mp4",".avi",".mkv",".mov",".wmv"],
    "Audio": [".mp3",".wav",".flac",".aac",".ogg"],
    "Code": [".py",".js",".html",".css",".java",".cpp",".rs",".go"],
    "Archives": [".zip",".rar",".7z",".tar",".gz"],
    "Executables": [".exe",".msi",".dmg"],
}


def file_hash(path, bs=65536):
    h = hashlib.md5()
    try:
        with open(path, "rb") as f:
            while True:
                chunk = f.read(bs)
                if not chunk: break
                h.update(chunk)
    except: return None
    return h.hexdigest()


def category(ext):
    ext = ext.lower()
    for cat, exts in EXTS.items():
        if ext in exts: return cat
    return "Other"


def organize(src, dest=None, dry_run=False):
    src = Path(src)
    dest = Path(dest) if dest else src / "Organized"
    stats = defaultdict(int)
    dupes = []
    hashes = {}
    files = [f for f in src.rglob("*") if f.is_file() and str(dest) not in str(f)]
    log.info("Found %d files in %s", len(files), src)
    for fp in files:
        fh = file_hash(fp)
        if fh and fh in hashes:
            dupes.append({"file": str(fp), "dupe_of": str(hashes[fh])})
            stats["duplicates"] += 1
            continue
        if fh: hashes[fh] = fp
        cat = category(fp.suffix)
        folder = dest / cat
        new = folder / fp.name
        if new.exists():
            new = folder / f"{fp.stem}_{int(datetime.now().timestamp())}{fp.suffix}"
        if dry_run:
            log.info("[DRY] %s -> %s", fp, new)
        else:
            folder.mkdir(parents=True, exist_ok=True)
            shutil.move(str(fp), str(new))
        stats[cat] += 1
    report = {"ts": str(datetime.now()), "src": str(src), "dest": str(dest),
        "total": len(files), "dupes": len(dupes), "by_cat": dict(stats), "dry_run": dry_run}
    dest.mkdir(parents=True, exist_ok=True)
    (dest / "report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    return report


if __name__ == "__main__":
    p = argparse.ArgumentParser(description="File Organizer")
    p.add_argument("source")
    p.add_argument("-d", "--dest")
    p.add_argument("--dry-run", action="store_true")
    a = p.parse_args()
    r = organize(a.source, a.dest, a.dry_run)
    print(json.dumps(r, indent=2))
