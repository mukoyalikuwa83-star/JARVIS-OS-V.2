# Newsletter SaaS: subscribers, campaigns

## Overview
A production-quality saas template.

## Installation
```bash
pip install -r requirements.txt
```

## Usage
```bash
python main.py --help
```

## License
MIT
