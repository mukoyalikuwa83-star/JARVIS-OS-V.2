"""ETL Pipeline - Extract, Transform, Load with config, logging, retry."""
import os, json, csv, time, logging, hashlib
from pathlib import Path
from datetime import datetime
from dataclasses import dataclass, asdict
from typing import List, Dict, Any

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger(__name__)


@dataclass
class PipelineConfig:
    name: str = "default"
    batch_size: int = 100
    max_retries: int = 3
    retry_delay: float = 1.0
    output_dir: str = "output"
    log_level: str = "INFO"


class Extractor:
    def extract_csv(self, filepath: str) -> List[Dict]:
        rows = []
        with open(filepath, "r", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                rows.append(dict(row))
        log.info("Extracted %d rows from %s", len(rows), filepath)
        return rows

    def extract_json(self, filepath: str) -> List[Dict]:
        data = json.loads(Path(filepath).read_text(encoding="utf-8"))
        if isinstance(data, list):
            return data
        return [data]

    def extract_jsonl(self, filepath: str) -> List[Dict]:
        rows = []
        for line in Path(filepath).read_text(encoding="utf-8").splitlines():
            if line.strip():
                rows.append(json.loads(line))
        return rows

    def extract(self, filepath: str) -> List[Dict]:
        ext = Path(filepath).suffix.lower()
        extractors = {".csv": self.extract_csv, ".json": self.extract_json, ".jsonl": self.extract_jsonl}
        fn = extractors.get(ext)
        if not fn:
            raise ValueError(f"Unsupported format: {ext}")
        return fn(filepath)


class Transformer:
    def __init__(self):
        self.transforms = []

    def add_transform(self, fn):
        self.transforms.append(fn)
        return self

    def rename_columns(self, mapping: Dict[str, str]):
        def transform(row):
            return {mapping.get(k, k): v for k, v in row.items()}
        self.transforms.append(transform)
        return self

    def filter_rows(self, predicate):
        self.transforms.append(lambda row: row if predicate(row) else None)
        return self

    def add_column(self, name: str, value_fn):
        def transform(row):
            row[name] = value_fn(row)
            return row
        self.transforms.append(transform)
        return self

    def deduplicate(self, key_fn=None):
        seen = set()
        def transform(row):
            key = key_fn(row) if key_fn else json.dumps(row, sort_keys=True)
            if key in seen:
                return None
            seen.add(key)
            return row
        self.transforms.append(transform)
        return self

    def clean_whitespace(self):
        def transform(row):
            return {k: v.strip() if isinstance(v, str) else v for k, v in row.items()}
        self.transforms.append(transform)
        return self

    def transform(self, rows: List[Dict]) -> List[Dict]:
        result = []
        for row in rows:
            current = row
            skip = False
            for t in self.transforms:
                current = t(current)
                if current is None:
                    skip = True
                    break
            if not skip:
                result.append(current)
        log.info("Transformed %d -> %d rows", len(rows), len(result))
        return result


class Loader:
    def save_csv(self, rows: List[Dict], filepath: str):
        if not rows:
            log.warning("No rows to save")
            return
        Path(filepath).parent.mkdir(parents=True, exist_ok=True)
        with open(filepath, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=rows[0].keys())
            writer.writeheader()
            writer.writerows(rows)
        log.info("Saved %d rows to %s", len(rows), filepath)

    def save_json(self, rows: List[Dict], filepath: str):
        Path(filepath).parent.mkdir(parents=True, exist_ok=True)
        Path(filepath).write_text(json.dumps(rows, indent=2, default=str), encoding="utf-8")
        log.info("Saved %d rows to %s", len(rows), filepath)

    def save_jsonl(self, rows: List[Dict], filepath: str):
        Path(filepath).parent.mkdir(parents=True, exist_ok=True)
        with open(filepath, "w", encoding="utf-8") as f:
            for row in rows:
                f.write(json.dumps(row, default=str) + "\n")
        log.info("Saved %d rows to %s", len(rows), filepath)


class Pipeline:
    def __init__(self, config: PipelineConfig = None):
        self.config = config or PipelineConfig()
        self.extractor = Extractor()
        self.transformer = Transformer()
        self.loader = Loader()
        self.stats = {"extracted": 0, "transformed": 0, "loaded": 0, "errors": 0, "start": None, "end": None}

    def run(self, input_file: str, output_file: str, output_format: str = "json"):
        self.stats["start"] = datetime.now().isoformat()
        log.info("Pipeline '%s' starting: %s -> %s", self.config.name, input_file, output_file)
        try:
            data = self.extractor.extract(input_file)
            self.stats["extracted"] = len(data)
            data = self.transformer.transform(data)
            self.stats["transformed"] = len(data)
            save_fn = {"csv": self.loader.save_csv, "json": self.loader.save_json,
                       "jsonl": self.loader.save_jsonl}.get(output_format, self.loader.save_json)
            save_fn(data, output_file)
            self.stats["loaded"] = len(data)
        except Exception as e:
            self.stats["errors"] += 1
            log.error("Pipeline error: %s", e)
            raise
        finally:
            self.stats["end"] = datetime.now().isoformat()
            log.info("Pipeline stats: %s", json.dumps(self.stats))
        return self.stats


def run_demo():
    demo_dir = Path("demo_data")
    demo_dir.mkdir(exist_ok=True)
    csv_file = demo_dir / "input.csv"
    csv_file.write_text(
        "name,email,department,salary\n"
        "Alice,alice@example.com,Engineering,95000\n"
        "Bob,bob@example.com,Marketing,72000\n"
        "Charlie,charlie@example.com,Engineering,105000\n"
        "Diana,diana@example.com,Sales,68000\n"
        "Eve,eve@example.com,Engineering,98000\n"
        "Frank,frank@example.com,Marketing,71000\n",
        encoding="utf-8"
    )
    config = PipelineConfig(name="demo", batch_size=10)
    pipeline = Pipeline(config)
    pipeline.transformer.clean_whitespace()
    pipeline.transformer.add_column("bonus", lambda r: round(float(r.get("salary", 0)) * 0.1, 2))
    pipeline.transformer.add_column("processed_at", lambda r: datetime.now().isoformat())
    stats = pipeline.run(str(csv_file), str(demo_dir / "output.json"))
    print(f"Pipeline complete: {json.dumps(stats, indent=2)}")
    output = json.loads((demo_dir / "output.json").read_text(encoding="utf-8"))
    print(f"Output preview: {json.dumps(output[:2], indent=2)}")


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "demo":
        run_demo()
    else:
        print("Usage: python pipeline.py demo")
        print("Or import and use: Pipeline().run(input, output)")
