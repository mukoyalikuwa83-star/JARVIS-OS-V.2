# Analytics dashboard: campaigns, funnels

## Overview
A production-quality web dashboard.

## Installation
```bash
pip install -r requirements.txt
```

## Usage
```bash
python main.py --help
```

## License
MIT
