chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === "process") {
    fetch(msg.url || "https://httpbin.org/get")
      .then(r => r.json())
      .then(data => sendResponse({result: JSON.stringify(data).slice(0, 200)}))
      .catch(e => sendResponse({result: "Error: " + e.message}));
    return true;
  }
});