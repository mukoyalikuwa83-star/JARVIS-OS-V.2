document.getElementById("action").onclick = async () => {
  const url = document.getElementById("url").value;
  const data = document.getElementById("data").value;
  const status = document.getElementById("status");
  status.textContent = "Processing...";
  status.className = "status";
  try {
    const resp = await chrome.runtime.sendMessage({action: "process", url, data});
    status.textContent = resp.result || "Done";
    status.className = "status active";
  } catch(e) { status.textContent = "Error: " + e.message; }
};