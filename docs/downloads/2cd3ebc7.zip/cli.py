#!/usr/bin/env python3
"""CLI Tool - Production command-line tool with subcommands, config, plugins."""
import sys, os, json, argparse, logging, time
from pathlib import Path
from datetime import datetime

CONFIG_DIR = Path.home() / ".mytool"
CONFIG_FILE = CONFIG_DIR / "config.json"
DATA_DIR = CONFIG_DIR / "data"

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger(__name__)


class Config:
    def __init__(self):
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        self.data = self._load()

    def _load(self):
        if CONFIG_FILE.exists():
            return json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
        return {"theme": "dark", "editor": "code", "auto_save": True, "max_recent": 10}

    def save(self):
        CONFIG_FILE.write_text(json.dumps(self.data, indent=2), encoding="utf-8")

    def get(self, key, default=None):
        return self.data.get(key, default)

    def set(self, key, value):
        self.data[key] = value
        self.save()


class Store:
    def __init__(self):
        self.file = DATA_DIR / "items.json"
        self.items = self._load()

    def _load(self):
        if self.file.exists():
            return json.loads(self.file.read_text(encoding="utf-8"))
        return []

    def save(self):
        self.file.write_text(json.dumps(self.items, indent=2, default=str), encoding="utf-8")

    def add(self, name, tags=None, meta=None):
        item = {"id": len(self.items) + 1, "name": name, "tags": tags or [],
                "meta": meta or {}, "created": datetime.now().isoformat(),
                "updated": datetime.now().isoformat()}
        self.items.append(item)
        self.save()
        return item

    def get(self, item_id):
        for item in self.items:
            if item["id"] == item_id:
                return item
        return None

    def list(self, tag=None, limit=20):
        items = self.items
        if tag:
            items = [i for i in items if tag in i.get("tags", [])]
        return items[-limit:]

    def update(self, item_id, **kwargs):
        item = self.get(item_id)
        if item:
            item.update(kwargs)
            item["updated"] = datetime.now().isoformat()
            self.save()
        return item

    def delete(self, item_id):
        item = self.get(item_id)
        if item:
            self.items = [i for i in self.items if i["id"] != item_id]
            self.save()
            return True
        return False

    def search(self, query):
        q = query.lower()
        return [i for i in self.items if q in i["name"].lower() or any(q in t for t in i.get("tags", []))]

    def stats(self):
        return {"total": len(self.items), "tags": list(set(t for i in self.items for t in i.get("tags", [])))}


def cmd_init(args):
    config = Config()
    print(f"Initialized config at {CONFIG_DIR}")
    print(f"Config: {json.dumps(config.data, indent=2)}")


def cmd_add(args):
    store = Store()
    item = store.add(args.name, tags=args.tags.split(",") if args.tags else None)
    print(f"Added: {item['name']} (id={item['id']})")


def cmd_list(args):
    store = Store()
    items = store.list(tag=args.tag, limit=args.limit)
    if not items:
        print("No items found.")
        return
    for item in items:
        tags = ", ".join(item.get("tags", []))
        print(f"  [{item['id']}] {item['name']}" + (f" ({tags})" if tags else ""))


def cmd_get(args):
    store = Store()
    item = store.get(args.id)
    if item:
        print(json.dumps(item, indent=2, default=str))
    else:
        print(f"Item {args.id} not found.")


def cmd_delete(args):
    store = Store()
    if store.delete(args.id):
        print(f"Deleted item {args.id}")
    else:
        print(f"Item {args.id} not found.")


def cmd_search(args):
    store = Store()
    items = store.search(args.query)
    for item in items:
        print(f"  [{item['id']}] {item['name']}")


def cmd_stats(args):
    store = Store()
    stats = store.stats()
    print(f"Total items: {stats['total']}")
    print(f"Tags: {', '.join(stats['tags']) or 'none'}")


def cmd_config(args):
    config = Config()
    if args.key and args.value:
        config.set(args.key, args.value)
        print(f"Set {args.key} = {args.value}")
    elif args.key:
        print(f"{args.key} = {config.get(args.key)}")
    else:
        print(json.dumps(config.data, indent=2))


def main():
    parser = argparse.ArgumentParser(description="CLI Tool", formatter_class=argparse.RawDescriptionHelpFormatter,
                                     epilog="Examples:\n  mytool add 'My Item' --tags work,important\n  mytool list --tag work\n  mytool search item")
    sub = parser.add_subparsers(dest="command", help="Available commands")

    sub.add_parser("init", help="Initialize config")
    p_add = sub.add_parser("add", help="Add item")
    p_add.add_argument("name", help="Item name")
    p_add.add_argument("--tags", help="Comma-separated tags")
    p_add.set_defaults(func=cmd_add)

    p_list = sub.add_parser("list", help="List items")
    p_list.add_argument("--tag", help="Filter by tag")
    p_list.add_argument("--limit", type=int, default=20)
    p_list.set_defaults(func=cmd_list)

    p_get = sub.add_parser("get", help="Get item by ID")
    p_get.add_argument("id", type=int)
    p_get.set_defaults(func=cmd_get)

    p_del = sub.add_parser("delete", help="Delete item")
    p_del.add_argument("id", type=int)
    p_del.set_defaults(func=cmd_delete)

    p_search = sub.add_parser("search", help="Search items")
    p_search.add_argument("query")
    p_search.set_defaults(func=cmd_search)

    sub.add_parser("stats", help="Show statistics")

    p_config = sub.add_parser("config", help="View/set config")
    p_config.add_argument("key", nargs="?")
    p_config.add_argument("value", nargs="?")
    p_config.set_defaults(func=cmd_config)

    args = parser.parse_args()
    if hasattr(args, "func"):
        args.func(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
