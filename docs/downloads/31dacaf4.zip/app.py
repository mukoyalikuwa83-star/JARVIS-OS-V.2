"""SaaS Starter - Flask app with user auth, billing hooks, dashboard, API."""
import os, json, secrets, time, functools, logging
from datetime import datetime
from flask import Flask, request, jsonify, render_template_string, redirect, url_for, session

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", secrets.token_hex(32))
app.config["SESSION_COOKIE_SECURE"] = False
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger(__name__)

_users = {}
_plans = {"free": {"name": "Free", "price": 0, "features": ["5 projects", "1GB storage"]},
          "pro": {"name": "Pro", "price": 29, "features": ["Unlimited projects", "100GB storage", "Priority support"]},
          "enterprise": {"name": "Enterprise", "price": 99, "features": ["Everything in Pro", "Custom domain", "SLA"]}}

LANDING_HTML = """<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Jarvis SaaS</title>
<style>*{margin:0;padding:0;box-sizing:border-box}
body{font-family:system-ui,sans-serif;background:#0a0a0a;color:#e0e0e0}
.hero{text-align:center;padding:100px 20px 60px;background:linear-gradient(180deg,#0a0a0a 0%,#1a1a2e 100%)}
.hero h1{font-size:3em;background:linear-gradient(135deg,#00d4ff,#7b2ff7);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.hero p{color:#888;font-size:1.2em;margin:16px 0 32px}
.btn{display:inline-block;padding:14px 32px;border-radius:8px;font-weight:600;text-decoration:none;font-size:1em}
.btn-primary{background:linear-gradient(135deg,#00d4ff,#7b2ff7);color:#fff}
.btn-secondary{background:#1a1a2e;color:#00d4ff;border:1px solid #333}
.pricing{display:flex;justify-content:center;gap:24px;padding:60px 20px;flex-wrap:wrap}
.price-card{background:#111;border:1px solid #222;border-radius:12px;padding:32px;width:280px;text-align:center}
.price-card.featured{border-color:#7b2ff7}
.price-card h3{margin-bottom:8px}.price{font-size:2.5em;font-weight:700;color:#00d4ff;margin:16px 0}
.price span{font-size:0.4em;color:#666}
.features{text-align:left;margin:20px 0}.features li{padding:6px 0;color:#aaa;list-style:none}
.features li::before{content:"✓ ";color:#34d399}
footer{text-align:center;padding:30px;color:#444;font-size:0.8em}
</style></head><body>
<div class="hero"><h1>Jarvis SaaS</h1><p>Build, ship, and monetize your products</p>
<a href="/register" class="btn btn-primary">Get Started Free</a> <a href="/login" class="btn btn-secondary">Login</a></div>
<div class="pricing">
<div class="price-card"><h3>Free</h3><div class="price">$0<span>/mo</span></div>
<ul class="features"><li>5 projects</li><li>1GB storage</li><li>Community support</li></ul></div>
<div class="price-card featured"><h3>Pro</h3><div class="price">$29<span>/mo</span></div>
<ul class="features"><li>Unlimited projects</li><li>100GB storage</li><li>Priority support</li><li>Custom domain</li></ul></div>
<div class="price-card"><h3>Enterprise</h3><div class="price">$99<span>/mo</span></div>
<ul class="features"><li>Everything in Pro</li><li>SLA guarantee</li><li>Dedicated support</li><li>SSO/SAML</li></ul></div>
</div><footer>Powered by Jarvis SaaS Template</footer></body></html>"""

DASHBOARD_HTML = """<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Dashboard</title>
<style>*{margin:0;padding:0;box-sizing:border-box}
body{font-family:system-ui,sans-serif;background:#0a0a0a;color:#e0e0e0;display:flex;min-height:100vh}
.side{width:240px;background:#111;padding:20px;border-right:1px solid #222}
.side h2{color:#00d4ff;margin-bottom:24px;font-size:1.1em}
.side a{display:block;padding:10px 16px;color:#888;text-decoration:none;border-radius:6px;margin-bottom:4px}
.side a:hover,.side a.active{background:#1a1a2e;color:#fff}
.main{flex:1;padding:30px}
.stat-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-bottom:30px}
.stat-card{background:#111;border:1px solid #222;border-radius:10px;padding:20px}
.stat-card .label{color:#666;font-size:0.85em}.stat-card .value{font-size:1.8em;font-weight:700;color:#fff;margin-top:4px}
table{width:100%;border-collapse:collapse}th,td{padding:12px;text-align:left;border-bottom:1px solid #1a1a1a}
th{color:#666;font-size:0.85em}.badge{padding:3px 10px;border-radius:12px;font-size:0.75em;font-weight:600}
.badge-pro{background:#1a1a2e;color:#7b2ff7}.badge-free{background:#1a1a1a;color:#666}
</style></head><body>
<div class="side"><h2>Jarvis SaaS</h2><a href="/" class="active">Dashboard</a><a href="/projects">Projects</a><a href="/api/docs">API</a><a href="/settings">Settings</a><a href="/logout">Logout</a></div>
<div class="main"><h1>Dashboard</h1><p style="color:#666;margin:4px 0 20px">Welcome, {{ user.email }}</p>
<div class="stat-grid"><div class="stat-card"><div class="label">Plan</div><div class="value">{{ user.plan }}</div></div>
<div class="stat-card"><div class="label">Projects</div><div class="value">{{ projects }}</div></div>
<div class="stat-card"><div class="label">API Calls</div><div class="value">{{ api_calls }}</div></div></div>
<h2 style="margin-bottom:16px">Recent Activity</h2>
<table><tr><th>Time</th><th>Action</th><th>Details</th></tr>
{% for a in activity %}<tr><td>{{ a.time }}</td><td>{{ a.action }}</td><td>{{ a.details }}</td></tr>{% endfor %}</table>
</div></body></html>"""

@app.route("/")
def landing():
    if "uid" in session:
        return redirect("/dashboard")
    return render_template_string(LANDING_HTML)

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "GET":
        return render_template_string("""<!DOCTYPE html><html><head><meta charset="utf-8"><title>Register</title>
<style>body{font-family:system-ui;background:#0a0a0a;color:#e0e0e0;display:flex;justify-content:center;align-items:center;height:100vh}
form{background:#111;padding:40px;border-radius:12px;width:360px;border:1px solid #222}
h2{margin-bottom:24px;color:#00d4ff}input{width:100%;padding:12px;margin-bottom:16px;background:#1a1a1a;border:1px solid #333;border-radius:6px;color:#fff;font-size:0.95em}
button{width:100%;padding:12px;background:linear-gradient(135deg,#00d4ff,#7b2ff7);color:#fff;border:none;border-radius:6px;font-weight:600;cursor:pointer}
</style></head><body><form method="POST"><h2>Create Account</h2>
<input name="email" placeholder="Email" required><input name="password" placeholder="Password" type="password" required>
<button type="submit">Register</button><p style="margin-top:16px;text-align:center;font-size:0.85em"><a href="/login" style="color:#00d4ff">Already have an account?</a></p></form></body></html>""")
    data = request.form
    email = data.get("email", "").strip().lower()
    password = data.get("password", "")
    if not email or not password:
        return "Missing fields", 400
    if email in _users:
        return "Email taken", 409
    uid = secrets.token_hex(8)
    _users[email] = {"id": uid, "email": email, "plan": "free", "created": datetime.now().isoformat(),
                     "api_calls": 0, "projects": 0}
    session["uid"] = uid
    session["email"] = email
    return redirect("/dashboard")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "GET":
        return render_template_string("""<!DOCTYPE html><html><head><meta charset="utf-8"><title>Login</title>
<style>body{font-family:system-ui;background:#0a0a0a;color:#e0e0e0;display:flex;justify-content:center;align-items:center;height:100vh}
form{background:#111;padding:40px;border-radius:12px;width:360px;border:1px solid #222}
h2{margin-bottom:24px;color:#00d4ff}input{width:100%;padding:12px;margin-bottom:16px;background:#1a1a1a;border:1px solid #333;border-radius:6px;color:#fff}
button{width:100%;padding:12px;background:linear-gradient(135deg,#00d4ff,#7b2ff7);color:#fff;border:none;border-radius:6px;font-weight:600;cursor:pointer}
</style></head><body><form method="POST"><h2>Login</h2>
<input name="email" placeholder="Email" required><input name="password" placeholder="Password" type="password" required>
<button type="submit">Login</button><p style="margin-top:16px;text-align:center;font-size:0.85em"><a href="/register" style="color:#00d4ff">Create account</a></p></form></body></html>""")
    email = request.form.get("email", "").strip().lower()
    user = _users.get(email)
    if not user:
        return "Invalid credentials", 401
    session["uid"] = user["id"]
    session["email"] = email
    return redirect("/dashboard")

@app.route("/dashboard")
def dashboard():
    if "uid" not in session:
        return redirect("/login")
    user = _users.get(session["email"], {})
    activity = [{"time": "Just now", "action": "Login", "details": "Successful login"}]
    return render_template_string(DASHBOARD_HTML, user=user, projects=user.get("projects", 0),
                                  api_calls=user.get("api_calls", 0), activity=activity)

@app.route("/logout")
def logout():
    session.clear()
    return redirect("/")

@app.route("/api/v1/<path:path>", methods=["GET", "POST", "PUT", "DELETE"])
def api_proxy(path):
    auth = request.headers.get("Authorization", "")
    token = auth.replace("Bearer ", "")
    if not token:
        return jsonify({"error": "API key required"}), 401
    email = None
    for e, u in _users.items():
        if u["id"] == token:
            email = e
            break
    if not email:
        return jsonify({"error": "Invalid API key"}), 401
    _users[email]["api_calls"] = _users[email].get("api_calls", 0) + 1
    return jsonify({"endpoint": path, "method": request.method, "status": "ok",
                    "plan": _users[email]["plan"]})

@app.route("/api/docs")
def api_docs():
    return jsonify({"endpoints": ["GET /api/v1/<path> - Generic API endpoint"],
                    "auth": "Bearer token in Authorization header",
                    "rate_limits": {"free": "100/hour", "pro": "1000/hour", "enterprise": "unlimited"}})

if __name__ == "__main__":
    print("SaaS app at http://localhost:5000")
    app.run(host="0.0.0.0", port=5000, debug=True)
