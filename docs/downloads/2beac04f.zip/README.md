# Professional chrome extension - production quality

## Overview
A production-quality chrome extension.

## Installation
```bash
pip install -r requirements.txt
```

## Usage
```bash
python main.py --help
```

## License
MIT
