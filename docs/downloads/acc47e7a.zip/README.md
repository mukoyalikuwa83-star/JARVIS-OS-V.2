# E-commerce API with auth, payments, inventory

## Overview
A production-quality etl pipeline.

## Installation
```bash
pip install -r requirements.txt
```

## Usage
```bash
python main.py --help
```

## License
MIT
