#!/usr/bin/env python3
"""Telegram Bot - Feature Rich
Search, translate, inline keyboards.
Requires: pip install python-telegram-bot
"""
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler,
    CallbackQueryHandler, ContextTypes, filters
import os


async def start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    kb = [[InlineKeyboardButton("Help", callback_data="help"),
           InlineKeyboardButton("About", callback_data="about")]]
    await update.message.reply_text(
        "Hello! I am your Telegram bot.\nChoose:",
        reply_markup=InlineKeyboardMarkup(kb))


async def help_cmd(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "/start - Welcome\n/help - This message\n"
        "/translate TEXT\n/search QUERY\nOr just send me a message!")


async def about(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if update.callback_query:
        await update.callback_query.edit_message_text("Telegram Bot")
    else:
        await update.message.reply_text("Telegram Bot")


async def button_handler(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    if q.data == "help": await help_cmd(update, ctx)
    elif q.data == "about": await about(update, ctx)


async def translate(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    text = " ".join(ctx.args) if ctx.args else ""
    if not text:
        await update.message.reply_text("Usage: /translate hello world")
        return
    await update.message.reply_text(f"Translation for: {text}")


async def search(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    q = " ".join(ctx.args) if ctx.args else ""
    if not q:
        await update.message.reply_text("Usage: /search python tutorials")
        return
    url = f"https://google.com/search?q={q.replace(chr(32), chr(43))}"
    await update.message.reply_text(f"Search: {q}\n{url}")


async def echo(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(f"You said: {update.message.text}\nUse /help")


if __name__ == "__main__":
    token = os.environ.get("TELEGRAM_TOKEN")
    if not token:
        print("Set TELEGRAM_TOKEN env var")
        exit(1)
    app = ApplicationBuilder().token(token).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_cmd))
    app.add_handler(CommandHandler("about", about))
    app.add_handler(CommandHandler("translate", translate))
    app.add_handler(CommandHandler("search", search))
    app.add_handler(CallbackQueryHandler(button_handler))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, echo))
    print("Bot started...")
    app.run_polling()
