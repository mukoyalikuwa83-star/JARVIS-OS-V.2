# Product page: features, buy

## Overview
A production-quality landing page.

## Installation
```bash
pip install -r requirements.txt
```

## Usage
```bash
python main.py --help
```

## License
MIT
