# Landing page with pricing and testimonials

## Overview
A production-quality cli tool.

## Installation
```bash
pip install -r requirements.txt
```

## Usage
```bash
python main.py --help
```

## License
MIT
