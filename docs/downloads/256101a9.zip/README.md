# File sharing API: upload, share, permissions

## Overview
A production-quality flask api.

## Installation
```bash
pip install -r requirements.txt
```

## Usage
```bash
python main.py --help
```

## License
MIT
