# File Manager, System Monitor, Task Scheduler

## Overview
A production-quality automation suite.

## Installation
```bash
pip install -r requirements.txt
```

## Usage
```bash
python main.py --help
```

## License
MIT
