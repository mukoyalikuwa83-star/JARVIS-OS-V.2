"""Automation Suite - File management, system monitoring, task scheduling."""
import os, json, time, shutil, hashlib, logging, subprocess, platform
from pathlib import Path
from datetime import datetime, timedelta
from concurrent.futures import ThreadPoolExecutor

log = logging.getLogger(__name__)

class FileManager:
    def __init__(self, base_dir="."):
        self.base = Path(base_dir)

    def organize(self, directory=None):
        target = Path(directory) if directory else self.base
        rules = {
            "Documents": [".pdf", ".doc", ".docx", ".txt", ".md", ".rtf"],
            "Images": [".jpg", ".jpeg", ".png", ".gif", ".bmp", ".svg", ".webp"],
            "Videos": [".mp4", ".avi", ".mkv", ".mov", ".wmv"],
            "Audio": [".mp3", ".wav", ".flac", ".aac", ".ogg"],
            "Code": [".py", ".js", ".ts", ".html", ".css", ".json", ".yaml"],
            "Archives": [".zip", ".tar", ".gz", ".7z", ".rar"],
            "Data": [".csv", ".xlsx", ".xls", ".json", ".sqlite", ".db"],
        }
        moved = 0
        for f in target.iterdir():
            if f.is_file():
                ext = f.suffix.lower()
                for folder, exts in rules.items():
                    if ext in exts:
                        dest = target / folder
                        dest.mkdir(exist_ok=True)
                        shutil.move(str(f), str(dest / f.name))
                        moved += 1
                        log.info("Moved %s -> %s/", f.name, folder)
                        break
        return {"moved": moved, "directory": str(target)}

    def find_duplicates(self, directory=None):
        target = Path(directory) if directory else self.base
        hashes = {}
        for f in target.rglob("*"):
            if f.is_file():
                h = hashlib.md5(f.read_bytes()).hexdigest()
                hashes.setdefault(h, []).append(str(f))
        return {h: files for h, files in hashes.items() if len(files) > 1}

    def cleanup_old(self, directory=None, days=30):
        target = Path(directory) if directory else self.base
        cutoff = datetime.now() - timedelta(days=days)
        removed = []
        for f in target.rglob("*"):
            if f.is_file():
                mtime = datetime.fromtimestamp(f.stat().st_mtime)
                if mtime < cutoff:
                    f.unlink()
                    removed.append(str(f))
        return {"removed": len(removed), "files": removed[:20]}

    def disk_usage(self):
        usage = {}
        for part in ["C:\", "D:\", "/"]:
            try:
                total, used, free = shutil.disk_usage(part)
                usage[part] = {"total_gb": round(total / (1024**3), 1),
                               "used_gb": round(used / (1024**3), 1),
                               "free_gb": round(free / (1024**3), 1)}
            except Exception:
                pass
        return usage


class SystemMonitor:
    def get_info(self):
        return {
            "platform": platform.platform(),
            "python": platform.python_version(),
            "processor": platform.processor(),
            "hostname": platform.node(),
        }

    def get_processes(self, filter_name=None):
        try:
            result = subprocess.run(["tasklist" if os.name == "nt" else "ps", "aux"],
                                  capture_output=True, text=True, timeout=5)
            lines = result.stdout.strip().split("
")
            procs = []
            for line in lines[1:]:
                parts = line.split()
                if len(parts) >= 2:
                    name = parts[0]
                    if filter_name and filter_name.lower() not in name.lower():
                        continue
                    procs.append({"name": name, "pid": parts[1] if len(parts) > 1 else "?"})
            return procs[:30]
        except Exception as e:
            return [{"error": str(e)}]


class TaskScheduler:
    def __init__(self, tasks_file="tasks.json"):
        self.tasks_file = Path(tasks_file)
        self.tasks = self._load()

    def _load(self):
        if self.tasks_file.exists():
            return json.loads(self.tasks_file.read_text())
        return []

    def _save(self):
        self.tasks_file.write_text(json.dumps(self.tasks, indent=2, default=str))

    def add(self, name, command, interval_minutes=60):
        task = {"name": name, "command": command, "interval": interval_minutes,
                "created": datetime.now().isoformat(), "last_run": None, "enabled": True}
        self.tasks.append(task)
        self._save()
        return task

    def run_due(self):
        results = []
        for task in self.tasks:
            if not task.get("enabled"):
                continue
            last = task.get("last_run")
            if last:
                elapsed = (datetime.now() - datetime.fromisoformat(last)).total_seconds() / 60
                if elapsed < task.get("interval", 60):
                    continue
            try:
                result = subprocess.run(task["command"], shell=True, capture_output=True,
                                      text=True, timeout=30)
                task["last_run"] = datetime.now().isoformat()
                results.append({"name": task["name"], "status": "ok", "output": result.stdout[:200]})
            except Exception as e:
                results.append({"name": task["name"], "status": "error", "error": str(e)})
        self._save()
        return results

    def list_tasks(self):
        return [{"name": t["name"], "command": t["command"], "interval": t["interval"],
                 "enabled": t["enabled"], "last_run": t.get("last_run")} for t in self.tasks]


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    fm = FileManager()
    print("Disk:", json.dumps(fm.disk_usage(), indent=2))
    sm = SystemMonitor()
    print("System:", json.dumps(sm.get_info(), indent=2))
    ts = TaskScheduler()
    ts.add("echo_test", "echo hello", 60)
    print("Tasks:", json.dumps(ts.list_tasks(), indent=2))
