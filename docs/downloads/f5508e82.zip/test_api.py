"""API Tests - Run with: python -m pytest test_api.py -v"""
import json, secrets
try:
    from app import app, _users, _items, _tokens
    HAS_FLASK = True
except ImportError:
    HAS_FLASK = False

def test_api():
    if not HAS_FLASK:
        print("Flask not installed, skipping tests")
        return
    client = app.test_client()
    # Health check
    r = client.get("/api/health")
    assert r.status_code == 200
    data = r.get_json()
    assert data["status"] == "ok"
    print("PASS: Health check")
    # Register
    email = f"test_{secrets.token_hex(4)}@example.com"
    r = client.post("/api/register", json={"email": email, "password": "pass123"})
    assert r.status_code == 201
    token = r.get_json()["token"]
    print("PASS: Register")
    # Login
    r = client.post("/api/login", json={"email": email, "password": "pass123"})
    assert r.status_code == 200
    print("PASS: Login")
    # Create item
    headers = {"Authorization": f"Bearer {token}"}
    r = client.post("/api/items", json={"name": "Test", "description": "A test item"}, headers=headers)
    assert r.status_code == 201
    item_id = r.get_json()["id"]
    print("PASS: Create item")
    # List items
    r = client.get("/api/items", headers=headers)
    assert r.status_code == 200
    assert r.get_json()["count"] >= 1
    print("PASS: List items")
    # Get item
    r = client.get(f"/api/items/{item_id}", headers=headers)
    assert r.status_code == 200
    assert r.get_json()["name"] == "Test"
    print("PASS: Get item")
    # Update item
    r = client.put(f"/api/items/{item_id}", json={"name": "Updated"}, headers=headers)
    assert r.status_code == 200
    assert r.get_json()["name"] == "Updated"
    print("PASS: Update item")
    # Delete item
    r = client.delete(f"/api/items/{item_id}", headers=headers)
    assert r.status_code == 200
    print("PASS: Delete item")
    # Unauthorized
    r = client.get("/api/items")
    assert r.status_code == 401
    print("PASS: Unauthorized blocked")
    print("\nAll tests passed!")

if __name__ == "__main__":
    test_api()
