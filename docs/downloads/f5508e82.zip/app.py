"""Flask REST API - Production backend with auth, CRUD, rate limiting."""
import os, json, time, secrets, functools, logging
from datetime import datetime, timedelta
from flask import Flask, request, jsonify, g
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", secrets.token_hex(32))
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger(__name__)

_users = {}
_items = {}
_tokens = {}
_rate_limits = {}


def rate_limit(max_per_minute=60):
    def dec(f):
        @functools.wraps(f)
        def wrapper(*a, **kw):
            ip = request.remote_addr
            now = time.time()
            window = [t for t in _rate_limits.get(ip, []) if now - t < 60]
            if len(window) >= max_per_minute:
                return jsonify({"error": "Rate limit exceeded"}), 429
            window.append(now)
            _rate_limits[ip] = window
            return f(*a, **kw)
        return wrapper
    return dec


def require_auth(f):
    @functools.wraps(f)
    def wrapper(*a, **kw):
        auth = request.headers.get("Authorization", "")
        token = auth.replace("Bearer ", "")
        if token not in _tokens:
            return jsonify({"error": "Unauthorized"}), 401
        g.user_id = _tokens[token]
        return f(*a, **kw)
    return wrapper


@app.route("/api/register", methods=["POST"])
@rate_limit(10)
def register():
    data = request.get_json() or {}
    email = data.get("email", "").strip().lower()
    password = data.get("password", "")
    if not email or not password:
        return jsonify({"error": "Email and password required"}), 400
    if email in _users:
        return jsonify({"error": "Email already registered"}), 409
    uid = secrets.token_hex(8)
    _users[email] = {"id": uid, "email": email, "password": generate_password_hash(password),
                     "created": datetime.now().isoformat(), "plan": "free"}
    token = secrets.token_urlsafe(32)
    _tokens[token] = uid
    log.info("Registered: %s", email)
    return jsonify({"token": token, "user_id": uid}), 201


@app.route("/api/login", methods=["POST"])
@rate_limit(30)
def login():
    data = request.get_json() or {}
    email = data.get("email", "").strip().lower()
    password = data.get("password", "")
    user = _users.get(email)
    if not user or not check_password_hash(user["password"], password):
        return jsonify({"error": "Invalid credentials"}), 401
    token = secrets.token_urlsafe(32)
    _tokens[token] = user["id"]
    log.info("Logged in: %s", email)
    return jsonify({"token": token, "user_id": user["id"]})


@app.route("/api/items", methods=["GET"])
@require_auth
@rate_limit(60)
def list_items():
    user_items = [v for v in _items.values() if v["owner"] == g.user_id]
    return jsonify({"items": user_items, "count": len(user_items)})


@app.route("/api/items", methods=["POST"])
@require_auth
@rate_limit(30)
def create_item():
    data = request.get_json() or {}
    if not data.get("name"):
        return jsonify({"error": "Name required"}), 400
    iid = secrets.token_hex(8)
    item = {"id": iid, "owner": g.user_id, "name": data["name"],
            "description": data.get("description", ""), "tags": data.get("tags", []),
            "metadata": data.get("metadata", {}), "created": datetime.now().isoformat(),
            "updated": datetime.now().isoformat()}
    _items[iid] = item
    log.info("Created item: %s", iid)
    return jsonify(item), 201


@app.route("/api/items/<item_id>", methods=["GET"])
@require_auth
def get_item(item_id):
    item = _items.get(item_id)
    if not item or item["owner"] != g.user_id:
        return jsonify({"error": "Not found"}), 404
    return jsonify(item)


@app.route("/api/items/<item_id>", methods=["PUT"])
@require_auth
def update_item(item_id):
    item = _items.get(item_id)
    if not item or item["owner"] != g.user_id:
        return jsonify({"error": "Not found"}), 404
    data = request.get_json() or {}
    for key in ("name", "description", "tags", "metadata"):
        if key in data:
            item[key] = data[key]
    item["updated"] = datetime.now().isoformat()
    return jsonify(item)


@app.route("/api/items/<item_id>", methods=["DELETE"])
@require_auth
def delete_item(item_id):
    item = _items.get(item_id)
    if not item or item["owner"] != g.user_id:
        return jsonify({"error": "Not found"}), 404
    del _items[item_id]
    return jsonify({"deleted": True})


@app.route("/api/health")
def health():
    return jsonify({"status": "ok", "users": len(_users), "items": len(_items),
                    "uptime": datetime.now().isoformat()})


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    print(f"API running on http://localhost:{port}")
    app.run(host="0.0.0.0", port=port, debug=True)
