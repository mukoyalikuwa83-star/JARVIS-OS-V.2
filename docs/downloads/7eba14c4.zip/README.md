# Discord bot: moderation

## Overview
A production-quality discord bot.

## Installation
```bash
pip install discord.py
```

## Usage
```bash
python bot.py
```

## License
MIT
