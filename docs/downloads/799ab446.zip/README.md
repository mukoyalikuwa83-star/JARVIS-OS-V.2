# Landing page with pricing and testimonials

## Overview
A production-quality telegram bot.

## Installation
```bash
pip install python-telegram-bot
```

## Usage
```bash
python bot.py
```

## License
MIT
