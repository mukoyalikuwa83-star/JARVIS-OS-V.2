# Chrome extension for productivity

## Overview
A production-quality telegram bot.

## Installation
```bash
pip install python-telegram-bot
```

## Usage
```bash
python bot.py
```

## License
MIT
