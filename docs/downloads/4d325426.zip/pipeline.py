"""Data Pipeline v2 - Streaming, parallel processing, monitoring."""
import json, csv, time, logging, os, hashlib, threading
from pathlib import Path
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed

log = logging.getLogger(__name__)

class Source:
    def __init__(self, name, reader_fn):
        self.name = name
        self.read = reader_fn

    @classmethod
    def csv_file(cls, path):
        def reader():
            with open(path, newline="", encoding="utf-8") as f:
                return list(csv.DictReader(f))
        return cls(Path(path).name, reader)

    @classmethod
    def json_file(cls, path):
        def reader():
            return json.loads(Path(path).read_text(encoding="utf-8"))
        return cls(Path(path).name, reader)

    @classmethod
    def dict_source(cls, name, data):
        return cls(name, lambda: data if isinstance(data, list) else [data])


class Transform:
    def __init__(self, name, fn):
        self.name = name
        self.apply = fn

    @classmethod
    def filter(cls, predicate):
        return cls("filter", lambda rows: [r for r in rows if predicate(r)])

    @classmethod
    def map_fields(cls, mapping):
        def fn(rows):
            result = []
            for r in rows:
                nr = {}
                for old_key, new_key in mapping.items():
                    if old_key in r:
                        nr[new_key] = r[old_key]
                result.append(nr)
            return result
        return cls("map_fields", fn)

    @classmethod
    def add_field(cls, key, value_fn):
        return cls(f"add_{key}", lambda rows: [{**r, key: value_fn(r)} for r in rows])

    @classmethod
    def dedupe(cls, key):
        return cls(f"dedupe_{key}", lambda rows: list({r[key]: r for r in rows}.values()))

    @classmethod
    def sort_by(cls, key, reverse=False):
        return cls(f"sort_{key}", lambda rows: sorted(rows, key=lambda r: r.get(key, ""), reverse=reverse))


class Sink:
    def __init__(self, name, writer_fn):
        self.name = name
        self.write = writer_fn

    @classmethod
    def json_file(cls, path):
        def writer(rows):
            Path(path).write_text(json.dumps(rows, indent=2, default=str), encoding="utf-8")
            return len(rows)
        return cls(f"json:{path}", writer)

    @classmethod
    def csv_file(cls, path):
        def writer(rows):
            if not rows: return 0
            with open(path, "w", newline="", encoding="utf-8") as f:
                w = csv.DictWriter(f, fieldnames=rows[0].keys())
                w.writeheader()
                w.writerows(rows)
            return len(rows)
        return cls(f"csv:{path}", writer)

    @classmethod
    def console(cls):
        return cls("console", lambda rows: (print(json.dumps(rows[:3], indent=2)), len(rows))[1])


class Pipeline:
    def __init__(self, name="pipeline"):
        self.name = name
        self.sources = []
        self.transforms = []
        self.sinks = []
        self.stats = {"started": None, "ended": None, "rows_in": 0, "rows_out": 0, "errors": 0}

    def add_source(self, source):
        self.sources.append(source)
        return self

    def add_transform(self, transform):
        self.transforms.append(transform)
        return self

    def add_sink(self, sink):
        self.sinks.append(sink)
        return self

    def run(self, parallel=False):
        self.stats["started"] = datetime.now().isoformat()
        log.info("Pipeline '%s' starting", self.name)
        all_rows = []
        for src in self.sources:
            try:
                rows = src.read()
                log.info("Source '%s': %d rows", src.name, len(rows))
                all_rows.extend(rows)
            except Exception as e:
                self.stats["errors"] += 1
                log.error("Source '%s' failed: %s", src.name, e)
        self.stats["rows_in"] = len(all_rows)
        for tf in self.transforms:
            try:
                all_rows = tf.apply(all_rows)
                log.info("Transform '%s': %d rows", tf.name, len(all_rows))
            except Exception as e:
                self.stats["errors"] += 1
                log.error("Transform '%s' failed: %s", tf.name, e)
        if parallel and len(self.sinks) > 1:
            with ThreadPoolExecutor(max_workers=len(self.sinks)) as pool:
                futures = {pool.submit(sink.write, all_rows): sink for sink in self.sinks}
                for f in as_completed(futures):
                    try:
                        self.stats["rows_out"] += f.result()
                    except Exception as e:
                        self.stats["errors"] += 1
                        log.error("Sink failed: %s", e)
        else:
            for sink in self.sinks:
                try:
                    self.stats["rows_out"] += sink.write(all_rows)
                except Exception as e:
                    self.stats["errors"] += 1
                    log.error("Sink '%s' failed: %s", sink.name, e)
        self.stats["ended"] = datetime.now().isoformat()
        log.info("Pipeline '%s' done: %s", self.name, json.dumps(self.stats))
        return self.stats


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    p = Pipeline("demo")
    p.add_source(Source.dict_source("input", [
        {"name": "Alice", "dept": "Eng", "salary": 95000},
        {"name": "Bob", "dept": "Sales", "salary": 72000},
        {"name": "Charlie", "dept": "Eng", "salary": 105000},
        {"name": "Diana", "dept": "Marketing", "salary": 68000},
    ]))
    p.add_transform(Transform.add_field("bonus", lambda r: round(r["salary"] * 0.1, 2)))
    p.add_transform(Transform.sort_by("salary", reverse=True))
    p.add_sink(Sink.json_file("output.json"))
    p.add_sink(Sink.console())
    stats = p.run()
    print(json.dumps(stats, indent=2))
