# Focus blocker: sites, timer

## Overview
A production-quality chrome extension.

## Installation
```bash
pip install -r requirements.txt
```

## Usage
```bash
python main.py --help
```

## License
MIT
